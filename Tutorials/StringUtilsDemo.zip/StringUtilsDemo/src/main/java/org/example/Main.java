package org.example;

import org.apache.commons.lang3.StringUtils;

import java.sql.SQLOutput;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        System.out.println("Given String : Hello world\nOutput :");

        String myString = "Hello World";
//        Boolean b = StringUtils.containsAny(myString, "abce");
//        System.out.println(b);

//        Boolean b = StringUtils.containsAnyIgnoreCase(myString , "LLo");
//        System.out.println(b);

        //Switch Case upper to lower and vise versa
//        System.out.println(StringUtils.swapCase("HelloWorld"));
//        System.out.println(StringUtils.swapCase("RohitGiNNare"));

        // Capitalize first letter of the sentense
//        System.out.println(StringUtils.capitalize("hello my name is rohit"));

        //
//        System.out.println(StringUtils.uncapitalize("Hello Rohit"));

        // Capitalize each word of the given sentence

        String myString1="Hello this method will capitalize each word's first letter capital";

        StringTokenizer tokenizer = new StringTokenizer(myString1, " ");

        while(tokenizer.hasMoreElements())
        {
            System.out.println(StringUtils.capitalize(tokenizer.nextToken()));
        }
    }
}